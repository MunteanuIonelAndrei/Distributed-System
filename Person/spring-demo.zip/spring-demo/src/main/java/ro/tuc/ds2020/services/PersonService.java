package ro.tuc.ds2020.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import ro.tuc.ds2020.controllers.handlers.exceptions.model.ResourceNotFoundException;
import ro.tuc.ds2020.dtos.PersonDTO;
import ro.tuc.ds2020.dtos.PersonDetailsDTO;
import ro.tuc.ds2020.dtos.builders.PersonBuilder;
import ro.tuc.ds2020.entities.Person;
import ro.tuc.ds2020.repositories.PersonRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class PersonService  implements UserService {

    private static final Logger LOGGER = LoggerFactory.getLogger(PersonService.class);
    private final PersonRepository personRepository;

    @Autowired
    public PersonService(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    public List<PersonDTO> findPersons() {
        List<Person> personList = personRepository.findAll();
        return personList.stream()
                .map(PersonBuilder::toPersonDTO)
                .collect(Collectors.toList());
    }

    public PersonDetailsDTO findPersonById(UUID id) {
        Optional<Person> prosumerOptional = personRepository.findById(id);
        if (!prosumerOptional.isPresent()) {
            LOGGER.error("Person with id {} was not found in db", id);
            throw new ResourceNotFoundException(Person.class.getSimpleName() + " with id: " + id);
        }
        return PersonBuilder.toPersonDetailsDTO(prosumerOptional.get());
    }

    public UUID insert(PersonDetailsDTO personDTO) {
        Person person = PersonBuilder.toEntity(personDTO);
        person = personRepository.save(person);
        LOGGER.debug("Person with id {} was inserted in db", person.getId());
        return person.getId();
    }

    public Person updatePerson(UUID id, String name, String password)
    {
        Person person = personRepository.findById(id).get();
        person.setName(name);
        person.setPassword(password);
        personRepository.save(person);
        LOGGER.debug("Person with id {} was updated in db", person.getId());
        return person;
    }

    public void deletePerson(UUID id)
    {
        Person person = personRepository.findById(id).get();
        LOGGER.debug("Person with id {} was deleted in db", person.getId());
        personRepository.deleteById(id);
    }

    public boolean checkRoleUser(UUID id){
        Person person =personRepository.findById(id).get();
        if(person.getRole().equals("user")){
            return true;
        }
        return false;
    }

    public UUID findBYParams(String password, String Name, String Role)
    {
        Person person = personRepository.findPersonByPasswordAndRoleAndName(password,Role,Name);
        return person.getId();
    }
    public UUID login(UUID id, String password) {
        Person person = personRepository.findPersonByIdAndPassword(id, password);

        if (person != null) {
            return person.getId();
        } else {
            throw new ResourceNotFoundException("Login failed. User not found or invalid credentials.");
        }
    }

    @Override
    public UserDetailsService userDetailsService(){
        return new UserDetailsService() {
            @Override
            public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {

               // return personRepository.findPersonById(UUID.fromString(s));
                return personRepository.findPersonById(UUID.fromString(s));
            }
        };
    }



}
