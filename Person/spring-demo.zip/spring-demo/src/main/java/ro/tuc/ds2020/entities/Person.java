package ro.tuc.ds2020.entities;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;
import org.hibernate.mapping.List;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Repository;
import ro.tuc.ds2020.dtos.validators.annotation.RoleAnnotation;

import jakarta.persistence.Entity;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.UUID;

@Entity(name = "person")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Data
@Builder
public class Person  implements Serializable, UserDetails {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    private UUID id;

    @Column(name = "name", nullable = false)
    private String name;
    @Column(name = "password",nullable = false)
    private String password;

    @Column(name = "role", nullable = false)
    @RoleAnnotation
    private String role;

    public Person(String name, String role, String password)
    {
        this.name=name;
        this.password = password;
        this.role = role; // Serialize the array to a string
    }
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Arrays.asList(new SimpleGrantedAuthority(role));
    }
    @Override
    public String getUsername() {
        System.out.println(id.toString());
        return id.toString();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

}
