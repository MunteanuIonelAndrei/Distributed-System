package ro.tuc.ds2020.dtos.validators.annotation;

import ro.tuc.ds2020.dtos.validators.RoleValidators;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;
import java.util.ArrayList;

@Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = {RoleValidators.class})
public @interface RoleAnnotation {

    String limit1() default "admin";
    String admin() default "admin";

    String user() default "user";

    String message() default "The role is not allowed";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
