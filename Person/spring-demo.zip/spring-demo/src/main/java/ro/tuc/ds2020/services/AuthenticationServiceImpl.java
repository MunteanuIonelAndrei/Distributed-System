package ro.tuc.ds2020.services;

import lombok.RequiredArgsConstructor;
import lombok.var;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import ro.tuc.ds2020.dtos.JwtAuthenticationResponse;
import ro.tuc.ds2020.dtos.RefreshTokenRequest;
import ro.tuc.ds2020.dtos.SignInRequest;
import ro.tuc.ds2020.dtos.SignUpRequest;
import ro.tuc.ds2020.dtos.validators.RoleValidators;
import ro.tuc.ds2020.entities.Person;
import ro.tuc.ds2020.repositories.PersonRepository;

import java.sql.SQLOutput;
import java.util.HashMap;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AuthenticationServiceImpl implements AuthenticationService {
    private final PersonRepository personRepository;
    private final PasswordEncoder passwordEncoder;
    private final RoleValidators roleValidators;
    private final AuthenticationManager authenticationManager;
    private final JWTService jwtService;

    public Person signUp(SignUpRequest signUpRequest){
        Person person = new Person();


        person.setName(signUpRequest.getName());
        person.setRole("user");
        person.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));

        return personRepository.save(person);
    }

    public JwtAuthenticationResponse signin(SignInRequest signInRequest) throws IllegalArgumentException {
authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(signInRequest.getId().toString(),signInRequest.getPassword()));

    var user = personRepository.findPersonById(signInRequest.getId());
        System.out.println(user.getName()+"s-a gasit user in db");
    var jwt = jwtService.generateToken(user);
    var refreshToken = jwtService.generaterefreshToken(new HashMap<>(),user);
    JwtAuthenticationResponse jwtAuthenticationResponse= new JwtAuthenticationResponse();
    jwtAuthenticationResponse.setToken(jwt);
    jwtAuthenticationResponse.setRefreshToken(refreshToken);
    return jwtAuthenticationResponse;
    }

    public JwtAuthenticationResponse refreshToken(RefreshTokenRequest refreshTokenRequest){
        String userID=jwtService.extractUserName(refreshTokenRequest.getToken());
        Person person = personRepository.findPersonById(UUID.fromString(userID));
        if(jwtService.isTokenvalid(refreshTokenRequest.getToken(),person)){
            var jwt =  jwtService.generateToken(person);
            JwtAuthenticationResponse jwtAuthenticationResponse= new JwtAuthenticationResponse();
            jwtAuthenticationResponse.setToken(jwt);
            jwtAuthenticationResponse.setRefreshToken(refreshTokenRequest.getToken());
            return jwtAuthenticationResponse;
        }
        return null;
    }


}
