package ro.tuc.ds2020.services;

import ro.tuc.ds2020.dtos.JwtAuthenticationResponse;
import ro.tuc.ds2020.dtos.RefreshTokenRequest;
import ro.tuc.ds2020.dtos.SignInRequest;
import ro.tuc.ds2020.dtos.SignUpRequest;
import ro.tuc.ds2020.entities.Person;

public interface AuthenticationService {
    Person signUp(SignUpRequest signUpRequest);
    JwtAuthenticationResponse signin(SignInRequest signInRequest);
    JwtAuthenticationResponse refreshToken(RefreshTokenRequest refreshTokenRequest);
}
