package ro.tuc.ds2020.dtos.validators;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;
import ro.tuc.ds2020.dtos.validators.annotation.RoleAnnotation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.ArrayList;
@Component
@Setter
@Getter
public class RoleValidators implements ConstraintValidator<RoleAnnotation, String> {


    private String  admin;
    private String user;

    @Override
    public void initialize(RoleAnnotation constraintAnnotation) {
        this.user = constraintAnnotation.user();
        this.admin = constraintAnnotation.admin();
    }

    @Override
    public boolean isValid(String inputString, ConstraintValidatorContext constraintValidatorContext) {
        return inputString.equals(admin) || inputString.equals(user);
    }
}
