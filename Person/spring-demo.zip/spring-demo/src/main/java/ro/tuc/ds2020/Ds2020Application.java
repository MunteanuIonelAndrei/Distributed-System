package ro.tuc.ds2020;

import config.JwtAuthfilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.client.RestTemplate;
import ro.tuc.ds2020.dtos.validators.RoleValidators;
import ro.tuc.ds2020.dtos.validators.annotation.RoleAnnotation;
import ro.tuc.ds2020.entities.Person;
import ro.tuc.ds2020.repositories.PersonRepository;

import java.util.TimeZone;

@SpringBootApplication
@EnableJpaRepositories
@ComponentScan("config")
@ComponentScan("ro.tuc.ds2020.dtos.validators")
@ComponentScan("ro.tuc.ds2020.services")
//@ComponentScan("repositories")
public class Ds2020Application extends SpringBootServletInitializer implements CommandLineRunner{
    @Autowired
    private PersonRepository personRepository;
    private RoleAnnotation roleValidators;



    @Override

    protected SpringApplicationBuilder configure(SpringApplicationBuilder application)  {
        return application.sources(Ds2020Application.class);
    }

    public static void main(String[] args) {
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        SpringApplication.run(Ds2020Application.class, args);
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    public void run(String... args){
        Person adminAcc= personRepository.findByRole("admin");
        if(adminAcc==null){
            Person person = new Person();
            System.out.println("ALOO");

            person.setName("admin");
            person.setRole("admin");
            person.setPassword(new BCryptPasswordEncoder().encode("admin"));
            personRepository.save(person);

        }

    }
}
