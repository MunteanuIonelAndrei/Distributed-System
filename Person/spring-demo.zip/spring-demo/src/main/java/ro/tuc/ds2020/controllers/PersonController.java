package ro.tuc.ds2020.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.data.web.JsonPath;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import ro.tuc.ds2020.dtos.PersonDTO;
import ro.tuc.ds2020.dtos.PersonDetailsDTO;
import ro.tuc.ds2020.entities.Person;
import ro.tuc.ds2020.services.PersonService;

import javax.validation.Valid;
import java.util.List;
import java.util.UUID;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@CrossOrigin
@RequestMapping(value = "/person")
public class PersonController {

    private final PersonService personService;

    @Autowired
    public PersonController(PersonService personService) {
        this.personService = personService;
    }

    @Autowired
    public RestTemplate restTemplate;

    @GetMapping()
    public ResponseEntity<List<PersonDTO>> getPersons() {
        List<PersonDTO> dtos = personService.findPersons();
        for (PersonDTO dto : dtos) {
            Link personLink = linkTo(methodOn(PersonController.class)
                    .getPerson(dto.getId())).withRel("personDetails");
            dto.add(personLink);
        }
        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

    @PostMapping()
    public ResponseEntity<UUID> insertProsumer(@Valid @RequestBody PersonDetailsDTO personDTO) {
        UUID personID = personService.insert(personDTO);
        String personIDString = personID.toString(); // Convert UUID to a string
        restTemplate.postForEntity("http://localhost:8081/pers/insertingDB", personIDString, String.class);
        return new ResponseEntity<>(personID, HttpStatus.CREATED);
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<PersonDetailsDTO> getPerson(@PathVariable("id") UUID personId) {
        PersonDetailsDTO dto = personService.findPersonById(personId);
        return new ResponseEntity<>(dto, HttpStatus.OK);
    }

    @PostMapping("/{id}/{name}/{password}")
    public ResponseEntity<Person> updatePerson(@PathVariable("id") UUID id, @PathVariable("name") String name,@PathVariable("password") String password) {
        Person person = personService.updatePerson(id, name, password);
        return new ResponseEntity<>(person, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePerson(@PathVariable("id") UUID id)
    {
        personService.deletePerson(id);
        restTemplate.delete("http://localhost:8081/pers/deletePers/"+id);//??????????????



        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    @GetMapping("/{password}/{name}/{role}")
    public ResponseEntity<UUID> findByParams(@PathVariable("password") String password,@PathVariable("name")String name, @PathVariable("role") String role)
    {
        UUID id = personService.findBYParams(password,role, name);
        System.out.println(id.toString());
        return  new  ResponseEntity<>(id, HttpStatus.OK);
    }

    @GetMapping("/{id}/{password}")
    public ResponseEntity<UUID> logIn(@PathVariable("id") UUID id ,@PathVariable("password")String password)
    {
        UUID id2 = personService.login(id,password);
        System.out.println(id+"/"+password);
        return  new  ResponseEntity<>(id2, HttpStatus.OK);
    }

    @GetMapping("/role/{id}")
    public ResponseEntity<Boolean> getRole(@PathVariable("id") UUID id)
    {
        boolean id2 = personService.checkRoleUser(id);
        System.out.println(id2);
        return  new  ResponseEntity<>(id2, HttpStatus.OK);
    }


}
