package ro.tuc.ds2020.dtos;

import lombok.Data;

import java.util.UUID;

@Data
public class SignInRequest {
    private UUID id;
    private String password;
}
