package ro.tuc.ds2020.services;

import org.springframework.security.core.userdetails.UserDetails;
import ro.tuc.ds2020.entities.Person;

import java.util.HashMap;
import java.util.Map;


public interface JWTService {
    String extractUserName(String token);
    String generateToken(UserDetails userDetails);
    boolean isTokenvalid(String token,UserDetails userDetails);

    String generaterefreshToken(Map<String, Object> extraClaims, UserDetails userDetails);
}
