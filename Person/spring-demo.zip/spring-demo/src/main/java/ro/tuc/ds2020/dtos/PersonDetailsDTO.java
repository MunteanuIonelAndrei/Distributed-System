package ro.tuc.ds2020.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;
import org.springframework.context.annotation.Role;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import ro.tuc.ds2020.dtos.validators.annotation.RoleAnnotation;

import javax.validation.constraints.NotNull;
import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PersonDetailsDTO {

    //@Type(type = "uuid-binary")
    private UUID id;
    @NotNull
    private String name;
    @NotNull
    private String password;
    @NotNull
    @RoleAnnotation
    private String role;

    public PersonDetailsDTO( String name, String role, String password) {
        this.name = name;
        this.password =password;
        this.role= role;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PersonDetailsDTO that = (PersonDetailsDTO) o;
        return
                Objects.equals(name, that.name) &&
                Objects.equals(role, that.role) &&
                Objects.equals(password,that.password);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name,password, role);
    }


}
