package config;


import lombok.RequiredArgsConstructor;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import ro.tuc.ds2020.dtos.validators.RoleValidators;
import ro.tuc.ds2020.services.UserService;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration {
    private final JwtAuthfilter jwtAuthfilter;
    private final UserService userService;

    @Autowired
    public SecurityConfiguration(JwtAuthfilter jwtAuthfilter, UserService userService)
    {
        this.jwtAuthfilter=jwtAuthfilter;
        this.userService=userService;
    }
    private  final RoleValidators roleValidators = new RoleValidators();
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception{

            http.csrf(AbstractHttpConfigurer::disable)
                    .authorizeRequests(request -> request.requestMatchers("/api/v1/auth/**")
                            .permitAll()
                            .requestMatchers("/api/v1/admin").hasAnyAuthority("admin")
                            .requestMatchers("/api/v1/user").hasAnyAuthority("user")
                            .anyRequest().authenticated())
                    .sessionManagement(manager -> manager.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                    .authenticationProvider(authProvider()).addFilterBefore(
                            jwtAuthfilter, UsernamePasswordAuthenticationFilter.class

                    );
            return http.build();
    }
    @Bean
    public AuthenticationProvider authProvider(){
        DaoAuthenticationProvider authenticationProvider=new DaoAuthenticationProvider();
        authenticationProvider.setUserDetailsService(userService.userDetailsService());
        authenticationProvider.setPasswordEncoder(passwordEncoder());
        return authenticationProvider;

    }
    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception{
        return configuration.getAuthenticationManager();
    }

}
